Kami, dengan bangga, meluncurkan: Alquran-app-beta.zip

Isinya adalah:
- README.md (file ini)
- index.html (File utama)
- Jalankan-alquran.bat (Aplikasi)

Catatan:
- File batch ini hanya berjalan di Windows
- Pastikan kamu punya Chrome
- Versi Mac, Android, dan Linux akan datang suatu saat

© Copyright Darul ilmi wal 'ilmu almaghribiyyah - All Rights Reserved
